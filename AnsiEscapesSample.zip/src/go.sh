#!/bin/bash
stty raw
java AnsiTest
stty -raw

